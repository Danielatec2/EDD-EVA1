/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package clases_examen;

/**
 *
 * @author danii
 */
public class TestCovid {
  private static int edad;
 private static int Ecronica;
 private static double peso; // El peso es en kilogramos
 private static double estatura; // La estatura es en metros
  public TestCovid(){
     edad = 0;
     Ecronica = 0; 
     peso = 0;
     estatura = 0;
   }
 
 public TestCovid(int edadTest, int EcronicaTest,double pesoTest,double estaturaTest){
     edad = edadTest;
     Ecronica= EcronicaTest;
     peso = pesoTest;
     estatura = estaturaTest;    
    }
  
 private double calcularIMC(){
    double IMC;
     return peso / (estatura*estatura);
 }

 public  void calcularPersonaRiesgo(){
     
     double imc = calcularIMC();

 }
 
 public int getEdad(){
     return edad;
 }
 public int getEcronica(){
     return Ecronica;
 }
 public double getPeso(){
     return peso; 
 }
 public double getEstatura(){
     return estatura;
 }
 public void setEdad(int valor){
     edad = valor;
 }
 public void setEcronica(int valor){
     Ecronica = valor;
 }
 public void setPeso(double valor){
     peso = valor;
 }
 public void setEstatura(double valor){
     estatura = valor;
 }
 public static void imprimirDatos(){
     //TestCovid covid= new TestCovid(); 
     
     double imc = calcularIMC();
     System.out.println("DATOS TEST");
     System.out.println("EDAD: " + edad);
     System.out.print("PADECE DE ENFERMEDAD CRONICA: ");
     
     if (Ecronica == 1){
         System.out.println("SI");
     }
     else{
         System.out.println("NO");
     }
         
     
     System.out.println("PESO: " + peso);
     System.out.println("ESTATURA: " + estatura);
     System.out.println("IMC: " +imc);
          
    if ((edad >= 65) || (Ecronica == 1) ||  (imc > 30)){
        System.out.println("PERSONA DE RIESGO");
    }
    else{  
        System.out.println("PERSONA SIN RIESGO");
    }
 }

 
    
}
